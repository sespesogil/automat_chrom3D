// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen

#ifndef GUARD_Segment
#define GUARD_Segment

#include <string>
#include <stdlib.h> //abs
#include <iostream>

struct Segment {
  Segment(std::string, int, int);
  std::string chr;
  int start;
  int end;
  int pos;
  bool operator < (const Segment& str) const {
    return (chr == str.chr ? pos < str.pos : chr < str.chr);
  }
  bool operator == (const Segment& str) const {
    return (chr == str.chr and start == str.start and end == str.end);
  }

  int operator - (const Segment& str) const {    
    return (chr == str.chr ? abs(pos - str.pos) : -1);
  }

};
#endif
