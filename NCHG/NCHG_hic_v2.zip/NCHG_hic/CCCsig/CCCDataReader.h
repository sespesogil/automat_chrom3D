// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen

#ifndef GUARD_CCCDataReader
#define GUARD_CCCDataReader

#include <string>
#include <map>
#include "CCCMatrix.h"
#include <vector>
#include <algorithm> 

class CCCDataReader {
 public:
  CCCDataReader(std::string);  
  void buildContactMatrices(bool onlyIntra=true);
  CCCMatrix<int> getContactMatrix(std::string);
  CCCMatrix<int> getContactMatrix(std::pair<std::string, std::string>);
  std::vector<CCCMatrix<int> > getContactMatrices();  
  std::vector<std::string> getChromosomes(bool onlyIntra=true);
  std::vector<std::pair<std::string, std::string> > getInterChromosomePairs();
 private:
  std::string filePath;
  std::map<std::string,CCCMatrix<int> > intraContactMatrices;
  std::map<std::pair<std::string, std::string>, CCCMatrix<int> > interContactMatrices;
};
#endif
