// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen


#include "CCCStatistics.h"
#include <iostream>

using namespace std;


map<int,int> computeQuantileMapper(vector<int>& vec, unsigned int nQuant) { 
// Function that computes quantiles of size quantSize and returns
// a map from each integer element to its quantile.
// Obs: If a given for delta is found in two adjacent divisions,
// then the smallest delta is used.
  int vecSize = vec.size();
  int quantSize = vecSize/nQuant;

  assert(vecSize > quantSize);

  sort(vec.begin(), vec.end()); 
  map<int, int> res;  
  int median = 0;
  int i = 0; 
  for (; i <= vecSize - quantSize; i += quantSize) {
    int midpos=i+(quantSize)/2;
    median = (quantSize % 2) ? vec[midpos] : (vec[midpos-1]+vec[midpos])/2;
    for(int j=i; j!=(i+quantSize); j++) {
      if(res.find(vec[j]) == res.end()) {
	res[vec[j]] = median;
      }
    }
  }
  int lastval=median;
  // Last remaindig chunk of values:
  if (i < vecSize) { 
    quantSize=(vecSize-i); // quantSize of final chunk
    int midpos=i+(quantSize)/2;
    median = (quantSize % 2) ? vec[midpos] : (vec[midpos-1]+vec[midpos])/2;
    for(int j=i; j!=(i+quantSize); j++) {
      if(res.size() >= nQuant) {
	res[vec[j]] = lastval; // Since the map is "full", set to the last value
      }
      else if(res.find(vec[j]) == res.end()) {
	res[vec[j]] = median;
      }
    }
  }
  return res;
}


map<int, vector<int> > getValuesPerDelta(ContactMatrix& cm, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool masking /*=false*/) {
  assert(cm.isIntra); // For the moment, only consider intra. Fix this later.
  map<int, vector<int> > res;
  set<Segment> segments = cm.getSegments(INTRAINDEX);
  typedef set<Segment>::iterator It;
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      int delta=(*i)-(*j);
      int value=cm.getElement(*i, *j);
      if((not (masking and cm.isMasked(*i, *j))) and (delta>=minDelta and delta<=maxDelta)) {
	res[delta].push_back(value);
      }
    }
  }
  return res;
}

map<int, vector<int> > getValuesPerDelta(ContactMatrix& cm, map<int,int>& quantileMapper, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool masking /*=false*/) {
  assert(cm.isIntra); // For the moment, only consider intra. Fix this later.
  map<int, vector<int> > res;
  set<Segment> segments = cm.getSegments(INTRAINDEX);
  typedef set<Segment>::iterator It;
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      int delta=(*i)-(*j);
      int value=cm.getElement(*i, *j);
      if((not (masking and cm.isMasked(*i, *j))) and (delta>=minDelta and delta<=maxDelta) ) {
	res[quantileMapper[delta]].push_back(value);
      }
    }
  }
  return res;
}






map<int, vector<int> > getValuesPerDelta(map<string, ContactMatrix>& matrices, map<int,int>& quantileMapper, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool masking /*=false*/) {
  map<int, vector<int> > res;
  set<Segment> segments;
  typedef set<Segment>::iterator It;
  
  //typedef vector<ContactMatrix>::iterator it;
  typedef map<string,ContactMatrix>::iterator it;
  for(it iter=matrices.begin(); iter!=matrices.end(); iter++) {
    if((iter->second).isIntra) {
      segments = (iter->second).getSegments(INTRAINDEX);    
      for (It i = segments.begin(); i != segments.end(); ++i) {
	for (It j = i; ++j != segments.end(); /**/) {
	  int delta=(*i)-(*j);
	  int value=(iter->second).getElement(*i, *j);
	  if((not (masking and iter->second.isMasked(*i, *j))) and (delta>=minDelta and delta<=maxDelta) ) {
	    res[quantileMapper[delta]].push_back(value);
	  }
	}
      }
    }    
  }
  return res;
}

template<typename T> map<Segment, T> getGlobalMarginalSumMapper(map<string, CCCMatrix<T> >& matrices, bool onlyIntra/*=true*/) {
  map<Segment, T> res;
  set<Segment> segments, segmentsRow, segmentsCol;
  typedef typename map<string,CCCMatrix<T> >::iterator it;
  typedef set<Segment>::iterator segIt;
  for(it iter=matrices.begin(); iter!=matrices.end(); iter++) {      
      if(iter->second.isIntra) { 
	segments = iter->second.getSegments(INTRAINDEX);
	for (segIt i = segments.begin(); i != segments.end(); ++i) {
	  res[*i] += iter->second.rowSum(*i); // rowSum == colSum for intra-matrices
	}
      }
      else if(not onlyIntra) {
	segmentsRow = iter->second.getSegments(ROWINDEX);
	segmentsCol = iter->second.getSegments(COLINDEX);
	for (segIt i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
	  res[*i] += iter->second.rowSum(*i); //
	}
	for (segIt i = segmentsCol.begin(); i != segmentsCol.end(); ++i) {
	  res[*i] += iter->second.colSum(*i); // 
	}
      }
  }
  return res;
}


map<int, float> getMeanPerDelta(map<int, vector<int> >& delta2ValueMapper) {
  map<int, float> res;
  typedef map<int, vector<int> >::iterator it;

  for(it iter=delta2ValueMapper.begin(); iter != delta2ValueMapper.end(); iter++) { // first: delta, second: values (vector of ints)
    int sum = accumulate((iter->second).begin(), (iter->second).end(), 0);
    float mean = (float)sum / (iter->second.size());
    res[iter->first] = mean;
  }
  return res;
}



ExpectationMatrix createExpectationMatrix(ContactMatrix& cm, map<int, float>& delta2ExpMapper, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/) {
  //assert(cm.isIntra); // This one works for inter- and intra data
  set<Segment> segmentsRow, segmentsCol;
  if(cm.isIntra) { 
    segmentsRow = cm.getSegments(INTRAINDEX);
    segmentsCol = cm.getSegments(INTRAINDEX);
  }
  else {
    segmentsRow = cm.getSegments(ROWINDEX);
    segmentsCol = cm.getSegments(COLINDEX);    
  }
  
  typedef set<Segment>::iterator It;
  ExpectationMatrix em(segmentsRow, segmentsCol, 0.0, cm.isIntra);
  if(cm.isIntra) {
    for (It i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
      for (It j = i; ++j != segmentsRow.end(); /**/) {
	int delta=(*i)-(*j);
	if(delta>=minDelta and delta<=maxDelta) {
	  float expectation=delta2ExpMapper[delta];
	  em.setElement(*i,*j, expectation);
	}
      }
    }
  }
  else {
    for (It i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
      for (It j = segmentsCol.begin(); j != segmentsCol.end(); ++j) {
	int delta=-1; // -1 is the code for interchromosomal interactions
	float expectation=delta2ExpMapper[delta];
	em.setElement(*i,*j, expectation);
      }
    }
  }
  return em;
}



double getMeanInterchromosomal(map<string, ContactMatrix>& matrices) {
  int sum = 0;
  int nElem = 0;
  typedef map<string,ContactMatrix>::iterator it;
  for(it iter=matrices.begin(); iter!=matrices.end(); iter++) {
    if(not (iter->second).isIntra) {
      sum += iter->second.sum();
      nElem += iter->second.nElem();
    }
  }
  return (double)sum/(double)nElem;
}



ExpectationMatrix createExpectationMatrix(ContactMatrix& cm, spline& smoothDelta2ExpMapper, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/) {
  assert(cm.isIntra); // For the moment, only consider intra. Fix this later.
  set<Segment> segments = cm.getSegments(INTRAINDEX);
  typedef set<Segment>::iterator It;
  ExpectationMatrix em(segments, segments, 0.0, true);

  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      int delta=(*i)-(*j);
      if(delta>=minDelta and delta<=maxDelta) {
	double expectation=smoothDelta2ExpMapper((double)delta);
	em.setElement(*i,*j, (float)expectation);
      }
    }
  }
  return em;
}

template<typename T> map<Segment, T> getMarginalSumMapper(CCCMatrix<T>& mat, IndexType marginal/*=INTRAINDEX*/) {
  if(marginal == INTRAINDEX) {
    assert(mat.isIntra);
  }
  
  map<Segment, T> res;
  set<Segment> segments = mat.getSegments(marginal);
  typedef set<Segment>::iterator It;
  for (It i = segments.begin(); i != segments.end(); ++i) {
    if(marginal == INTRAINDEX) {
      res[*i] = mat.rowSum(*i); // rowSum == colSum for intra-matrices
    }
    else if(marginal == ROWINDEX) {
      res[*i] = mat.rowSum(*i); // 
    }
    else if(marginal == COLINDEX) {
      res[*i] = mat.colSum(*i); // 
    }
    else {
      assert(false);
    }
    
  }
  return res;
}

map<Segment, float> estimateMarginalBias(ContactMatrix& mat, ExpectationMatrix& expmat, int nIter /*=20*/) {
  assert(mat.isIntra);
  set<Segment> segments = mat.getSegments(INTRAINDEX);
  typedef set<Segment>::iterator It;
  map<Segment, int> getRowSum = getMarginalSumMapper(mat);
  map<Segment, float> res, tmp;

  // Initiate bias vector to all 1s:
  for (It i = segments.begin(); i != segments.end(); ++i) {
    res[*i] = 1.0; 
    tmp[*i] = 0.0; 
  }
  for(int j=0; j!=nIter; j++) {
    for (It i = segments.begin(); i != segments.end(); ++i) {
      float a=getRowSum[*i] / expmat.weightedRowSum(*i, res);      
      res[*i] = (res[*i]+a)/2; // This averaging must be done to avoid fluctuations
    }
  }
  return res;
}



double getPvalNCHG(int nij, int ni, int nj, int n, double odds, double precision /*=1E-20*/, double minOmega /*=0.1*/) {
  double P;
  if(nij>0) {
    P = getCumulativeNCHG(nij-1, ni, nj, n, max(odds, minOmega), precision, false);
    if(P<0) {
      return 1;
    }
    else {
      return P;
    }
  }
  else {
    return 1;
  }
}

double getPvalFisher(int nij, int ni, int nj, int n) {
  double P;
  boost::math::hypergeometric_distribution<double> hg_dist(ni, nj, n);
  P = 1-boost::math::cdf<double>(hg_dist, nij-1);
  return P;
}


			  


double getCumulativeNCHG(int nij, int ni, int nj, int N, double odds, double precision /*=1E-20*/, bool lower_tail /*=true*/) {
  // Some assertions here
  int n=nj;
  int m1=ni;
  //int m2=N-ni;
  
  int xmin = m1 + n - N;  if (xmin < 0) xmin = 0;  // Minimum x
  int xmax = n;  if (xmax > m1) xmax = m1;         // Maximum x

  //int BufferLength;
  int x1, x2, x;
  double sum, p;
  double* buff = 0;

  CFishersNCHypergeometric xhyp(nj, ni, N, odds, precision);
  int BufferLength = (int)xhyp.MakeTable(buff, 0, &x1, &x2, precision * 0.001);
  //double buffer[BufferLength];
  double* buffer = new double[BufferLength]();
  
  
  double factor = 1. / xhyp.MakeTable(buffer, BufferLength, &x1, &x2, precision * 0.001); // make table of probability values
  int xmean = (int)(xhyp.mean() + 0.5);           // Round mean

  assert(xmean >= x1);
  assert(xmean <= x2);

  for (x = x1, sum = 0; x <= xmean; x++) sum = buffer[x-x1] += sum; // Make left tail of table cumulative
  for (x = x2, sum = 0; x > xmean; x--) sum = buffer[x-x1] += sum;  // Make right tail of table cumulative from the right

  
  x = nij;                       // Input x value
  if (x <= xmean) { // Left tail
    if (x < x1) {
      p = 0.;                    // Outside table
    }
    else {
      p = buffer[x-x1] * factor; // Probability from table
    }
    if (!lower_tail) p = 1. - p;  // Invert if right tail
  }
  else {      // Right tail    
    if (x >= x2) {
      p = 0.;                    // Outside table
    }
    else {
      p = buffer[x-x1+1] * factor; // Probability from table
    }
    if (lower_tail) p = 1. - p;   // Invert if left tail
  }
  delete[] buffer;
  return p;
}



int getQuantileNCHG(double p, int ni, int nj, int n, double odds, double precision, bool lower_tail /*=true*/) {
  assert(p >= 0 and p <=1);
  //int BufferLength;
  int x=0;
  int x1=0;
  int x2=0;
  double* buff = 0;
  double sum;
  unsigned int a, b, c; // Used in binary search

  CFishersNCHypergeometric xhyp(nj, ni, n, odds, precision);
  int BufferLength = (int)xhyp.MakeTable(buff, 0, &x1, &x2, precision * 0.001);
  if(BufferLength == 0) { return -1; } // Buffer cannot be allocated
  double buffer[BufferLength];
  double factor = xhyp.MakeTable(buffer, BufferLength, &x1, &x2, precision * 0.001); // make table of probability values
  
  for (x = x1, sum = 0; x <= x2; x++) sum = buffer[x-x1] += sum; // Make table cumulative

  
  if (!lower_tail) p = 1. - p; // Invert if right tail
  p *= factor; // Table is scaled by factor
  
  // Binary search in table:
  a = 0; b = x2 - x1 + 1;
  while (a < b) {
    c = (a + b) / 2;
    if (p <= buffer[c]) {
      b = c;
    }
    else {
      a = c + 1;
    }
  }
  x = x1 + a;  
  if (x > x2) x = x2;           // Prevent values > xmax that occur because of small imprecisions
  return x;
}


  


PvalueMatrix calculatePvalues(ContactMatrix& mat, ExpectationMatrix& expmat, map<Segment, int> &marginalCounts, map<Segment, float> &marginalExpectations, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool globalN /*=false*/) {
  //assert(mat.isIntra == expmat.isIntra);

  set<Segment> segmentsRow, segmentsCol;

  if(mat.isIntra) {
    segmentsRow = mat.getSegments(INTRAINDEX);
    segmentsCol = segmentsRow;
  }
  else {
    segmentsRow = mat.getSegments(ROWINDEX);
    segmentsCol = mat.getSegments(COLINDEX);
  }

    
  PvalueMatrix res(segmentsRow, segmentsCol, 1, mat.isIntra);

  int N=0; 
  float L=0; 

  if(globalN) {    
    for(map<Segment, int>::iterator it=marginalCounts.begin(); it!=marginalCounts.end(); it++) {
      N+=it->second;
    }
    for(map<Segment, float>::iterator it=marginalExpectations.begin(); it!=marginalExpectations.end(); it++) {
      L+=it->second;
    }
    N=N/2; // Need to divide by two, since each interaction is counted twice across all marginals
    L=L/2;
  }
  else {
    N = mat.getN(minDelta, maxDelta);
    L = expmat.getN(minDelta, maxDelta);
  }


  
  typedef set<Segment>::iterator It;
  float Li, Lj, Lij, Omega, OddsRatio;
  int Ni,Nj, Nij, delta;
  double pval;
  for (It i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
    //for (It j = i; ++j != segments.end(); /**/) {
    for (It j = segmentsCol.begin(); j != segmentsCol.end(); ++j) {
      if(mat.isIntra and (*i) < (*j)) {
	continue;
      }
      delta = (mat.isIntra) ? (*i)-(*j) : -1;
      if(!mat.isIntra or (mat.isIntra and delta >= minDelta and delta <= maxDelta)) {
	Li = marginalExpectations[(*i)];
	Lj = marginalExpectations[(*j)];;
	Ni = marginalCounts[(*i)];
	Nj = marginalCounts[(*j)];
	Nij = mat.getElement((*i), (*j));
	Lij = expmat.getElement((*i), (*j));
	Lij = max(Lij, 1E-20f); // Arbitrary cutoff, but expectation cannot be negative or zero!
	if (((Li-Lij)*(Lj-Lij)) > 1E-20 ) { // Kind of arbitrary cutoff, but needs to be set at some low value to avoid Omega = Inf
	  Omega = (mat.isIntra) ? (Lij*(2*L-Li-Lj+Lij)) / ((Li-Lij)*(Lj-Lij)) : 1;
	  OddsRatio = (Nij*(2*(float)N-(float)Ni-(float)Nj+(float)Nij)) / (((float)Ni-(float)Nij)*((float)Nj-(float)Nij));
	  
	  if(Omega > OddsRatio) { // It does not make sense to test in this case. 
	    pval = 1;
	  }
	  else {
	    if(mat.isIntra) {
	      pval = getPvalNCHG(Nij, Ni,Nj, 2*N, Omega);
	    }
	    else {
	      //pval = getPvalNCHG(Nij, Ni,Nj, N, 1.0);
	      pval = getPvalFisher(Nij, Ni,Nj, N);
	    }
	  }
		
	} 
	else {
	  pval = 1;
	}
	res.setElement(*i, *j, pval);       
      }
      else {
	res.setElement(*i, *j, 1);       
      }
    }
  }
  return res;
}











void printPositives(PvalueMatrix& pvalmat, ContactMatrix& mat, ExpectationMatrix& expmat, double alpha, int cutoff, bool printNij /*=false*/) {
  //assert(pvalmat.isIntra);
  //assert(mat.isIntra);
  set<Segment> segmentsRow, segmentsCol;
  if(pvalmat.isIntra) { 
    segmentsRow = pvalmat.getSegments(INTRAINDEX);
    segmentsCol = pvalmat.getSegments(INTRAINDEX);
  }
  else {
    segmentsRow = pvalmat.getSegments(ROWINDEX);
    segmentsCol = pvalmat.getSegments(COLINDEX);    
  }

  typedef set<Segment>::iterator It;  
  for (It i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
    for (It j = segmentsCol.begin(); j != segmentsCol.end(); ++j) {
      if(pvalmat.isIntra and (*j) < (*i)) {
	continue;
      }
      if(pvalmat.getElement(*i,*j) <= alpha and mat.getElement(*i, *j) >= cutoff) {	
	cout << (*i).chr << " " << (*i).start << " " << (*i).end << " " <<  (*j).chr << " " << (*j).start << " " << (*j).end << " " << pvalmat.getElement(*i,*j);
	if(printNij) {
	  cout << " " << mat.getElement(*i,*j) << " " << expmat.getElement(*i,*j);
	}
	cout << endl;
      }
    }
  }
}

void printPositives(PvalueMatrix& pvalmat, ContactMatrix& mat, ExpectationMatrix& expmat,  map<Segment, int> &marginalCounts, map<Segment, float> &marginalExpectations, double alpha, int cutoff, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool globalN /*=false*/) {
  set<Segment> segmentsRow, segmentsCol;
  if(pvalmat.isIntra) {
    segmentsRow = pvalmat.getSegments(INTRAINDEX);
    segmentsCol = pvalmat.getSegments(INTRAINDEX);
  }
  else {
    segmentsRow = pvalmat.getSegments(ROWINDEX);
    segmentsCol = pvalmat.getSegments(COLINDEX);
  }

  int N=0;
  float L=0;
  float Li, Lj, Lij, Omega, OddsRatio;
  int Ni,Nj, Nij, delta;

  if(globalN) {
    for(map<Segment, int>::iterator it=marginalCounts.begin(); it!=marginalCounts.end(); it++) {
      N+=it->second;
    }
    for(map<Segment, float>::iterator it=marginalExpectations.begin(); it!=marginalExpectations.end(); it++) {
      L+=it->second;
    }
    N=N/2; // Need to divide by two, since each interaction is counted twice across all marginals
    L=L/2;
  }
  else {
    N = mat.getN(minDelta, maxDelta);
    L = expmat.getN(minDelta, maxDelta);
  }


  typedef set<Segment>::iterator It;
  for (It i = segmentsRow.begin(); i != segmentsRow.end(); ++i) {
    for (It j = segmentsCol.begin(); j != segmentsCol.end(); ++j) {
      if(pvalmat.isIntra and (*j) < (*i)) {
        continue;
      }
      if(pvalmat.getElement(*i,*j) <= alpha and mat.getElement(*i, *j) >= cutoff) {
        cout << (*i).chr << " " << (*i).start << " " << (*i).end << " " <<  (*j).chr << " " << (*j).start << " " << (*j).end << " " << pvalmat.getElement(*i,*j);
	  Li = marginalExpectations[(*i)];
          Lj = marginalExpectations[(*j)];;
          Ni = marginalCounts[(*i)];
          Nj = marginalCounts[(*j)];
          Nij = mat.getElement((*i), (*j));
          Lij = expmat.getElement((*i), (*j));
          Lij = max(Lij, 1E-20f); // Arbitrary cutoff, but expectation cannot be negative or zero
	  Nij = mat.getElement(*i,*j);
	  Omega = (mat.isIntra) ? (Lij*(2*L-Li-Lj+Lij)) / ((Li-Lij)*(Lj-Lij)) : 1;
	  OddsRatio = (Nij*(2*(float)N-(float)Ni-(float)Nj+(float)Nij)) / (((float)Ni-(float)Nij)*((float)Nj-(float)Nij));
          cout << " " << Nij << " " << Lij << " " << OddsRatio << " " << Omega <<  endl; //" | Ni:" << Ni << " Nj:" << Nj << " N:" << N <<  endl;
      }
    }
  }
}



// Utils:
template<typename T> vector<T> getSequence(T from, T to, int length) {
  assert(to > from);
  vector<T> res;
  T stepSize=(to-from)/(length-1);
  for(T i = from; i <= to; i+=stepSize) {
    res.push_back(i);
  }
  return res;
}

pair<double, double> getAlphaRange(map<double, double> alpha2FDR, double minFDR) {
  typedef map<double, double>::iterator it2;
  double alpha, FDR;
  pair<double, double> res;
  res.first = 0;
  res.second = 0;
  for(it2 iter = alpha2FDR.begin(); iter != alpha2FDR.end(); iter++) {
    alpha = iter->first;
    FDR = iter->second;
    //cout << "alpha/FDR: " << alpha << " " << FDR << endl;
    if(FDR > minFDR) {
      if(res.first != 0 ) {
	res.second = alpha;
	return res; // success! minFDR is within the range
      }
      else { // minFDR is not within the range. C
	res.first = 0;
	res.second = alpha;
	return res; // the right alpha must be somewhere between 0 and minFDR
      }
    }
    res.first = alpha;
  }
  // At this point, the right alpha must be somewhere between alpha and minFDR
  
  res.second = minFDR;
  return res;
}


void maskByAlpha(PvalueMatrix& pvalmat, ContactMatrix& mat, double alpha, int cutoff) {
  assert(pvalmat.isIntra);
  assert(mat.isIntra);
  set<Segment> segments = pvalmat.getSegments(INTRAINDEX);

  typedef set<Segment>::iterator It;  
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      if(pvalmat.getElement(*i,*j) <= alpha and mat.getElement(*i, *j) >= cutoff) {
	//cout << "masked: " << (*i).chr << " " << (*i).start << " " << (*i).end << " "  << (*j).chr << " " << (*j).start << " " << (*j).end << " "  <<  mat.getElement(*i, *j) << " " << pvalmat.getElement(*i,*j) << endl; 
	mat.setMask(*i, *j);
      }
    }
  }
}





pair<spline, vector<double> > estimateDeltaSpline(vector<string> chromosomes, map<string, ContactMatrix>& contactMatrices, int minDelta /*=8000*/, int maxDelta /*=MAXDELTA*/, bool masking /*=false*/, int percentiles /*=1000*/) {

  vector<int> deltas;


  // Get all deltas for all chromosomes:
  string chr;
  for(unsigned int i=0; i!=chromosomes.size(); i++) {
    chr=chromosomes[i];
    if(contactMatrices[chr].isIntra) {
      deltas+=contactMatrices[chr].getDeltas(minDelta, maxDelta, masking);
    }
  }
  
  map<int,int> quantileMapper = computeQuantileMapper(deltas, percentiles);
  
  map<int, vector<int> > delta2vals = getValuesPerDelta(contactMatrices, quantileMapper, minDelta, maxDelta, masking);
  map<int, float> delta2exps = getMeanPerDelta(delta2vals);

  typedef map<int, float>::iterator it;

  vector<double> delta_x; // x-object for spline generation
  vector<double> exp_y; // y-object for spline generation

  for(it iter = delta2exps.begin(); iter != delta2exps.end(); iter++) {
      delta_x.push_back((double)(iter->first));
      exp_y.push_back((double)(iter->second));
    //cout << iter->first << " " << iter->second << endl;
  }
 
  spline s;
  // If x is not sorted, an error will occur.
  s.set_points(delta_x,exp_y);    // currently it is required that X is already sorted
  return make_pair(s, delta_x);

}




// Add the possible template classes explicitly, to allow linker to find them:
// These are the only allowed:
template map<Segment, int> getGlobalMarginalSumMapper(map<string, CCCMatrix<int> >&, bool);
template map<Segment, float> getGlobalMarginalSumMapper(map<string, CCCMatrix<float> >&, bool);


template map<Segment,int> getMarginalSumMapper(CCCMatrix<int>&,IndexType); 
template map<Segment,float> getMarginalSumMapper(CCCMatrix<float>&,IndexType); 
template vector<double> getSequence(double from, double to, int length);
template vector<int> getSequence(int from, int to, int length);
template vector<float> getSequence(float from, float to, int length);

