// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen

#include <set>
#include <fstream>
#include <sstream>
#include <assert.h>
#include "CCCDataReader.h"
#include "Segment.h"
#include <iostream>
#include <utility> 

using namespace std;

CCCDataReader::CCCDataReader(string file) {  
  // The constructor determines the unique segments, and nothing more.
  // These are needed for all downstream analyses.
  // Currently, this is only based on intra-data.
  filePath = file;

  ifstream inFile(filePath.c_str());
  assert(inFile.good());
  string chrL, chrR;
  int startL, endL, startR, endR, nij;

  // Get information about (unique) Segments:

  map<string, set<Segment> > intraSegs;
  map<string, set<Segment> > interSegs;
  vector<pair<string, string> > chrPairs; 
  while (inFile >> chrL >> startL >> endL >> chrR >> startR >> endR >> nij) {
    //assert(chrL == chrR); // Only support intra-data at the moment.
    bool isIntra = (chrL == chrR);
    Segment segL(chrL, startL, endL);
    Segment segR(chrR, startR, endR);
    if(isIntra) {
      intraSegs[chrL].insert(segL);
      intraSegs[chrR].insert(segR);
    }
    else {
      interSegs[chrL].insert(segL);
      interSegs[chrR].insert(segR);
      pair<string, string> chrPair = (chrL < chrR) ? make_pair(chrL, chrR) : make_pair(chrR, chrL);
      chrPairs.push_back(chrPair);
    }
  }

  // Loop through chromosomes, and build empty INTRAchromosomal matrices:
  typedef map<string, set<Segment> >::iterator it_type;
  for(it_type iterator = intraSegs.begin(); iterator != intraSegs.end(); iterator++) {      
    CCCMatrix<int> mat(iterator->second, iterator->second, 0, true);
    intraContactMatrices[iterator->first] = mat;
  }

  // Loop through chromosomes, and build empty INTERchromosomal matrices:
  //typedef map<string, set<Segment> >::iterator it_type;
  typedef vector<pair<string, string> >::iterator chrpairiter;  
  for(chrpairiter chrpair = chrPairs.begin(); chrpair != chrPairs.end(); chrpair++) {
    string chrL = chrpair->first;
    string chrR = chrpair->second;
    CCCMatrix<int> mat(interSegs[chrL], interSegs[chrR], 0, false);
    interContactMatrices[make_pair(chrL,chrR)] = mat;
  }
  
  inFile.close();
}
  

void CCCDataReader::buildContactMatrices(bool onlyIntra/*=true*/) {
  ifstream inFile(filePath.c_str());
  string chrL, chrR;
  int startL, endL, startR, endR, nij;
  float nij_tmp;
  assert(inFile.good());
  while (inFile >> chrL >> startL >> endL >> chrR >> startR >> endR >> nij_tmp) {
    bool isIntra = (chrL == chrR); 
    Segment segL(chrL, startL, endL);
    Segment segR(chrR, startR, endR);
    nij = (int)nij_tmp;
    if(isIntra) {
      intraContactMatrices[chrL].setElement(segL, segR, nij);
    }
    if(not isIntra and not onlyIntra) {
      pair<string, string> chrPair = (chrL < chrR) ? make_pair(chrL, chrR) : make_pair(chrR, chrL);
      pair<Segment, Segment> segPair = (chrL < chrR) ? make_pair(segL, segR) : make_pair(segR, segL);
      interContactMatrices[chrPair].setElement(segPair.first, segPair.second, nij);
    }

  }
  inFile.close();  
}

CCCMatrix<int> CCCDataReader::getContactMatrix(string chr) {
  assert(intraContactMatrices.count(chr) != 0);
  return intraContactMatrices[chr];
}

CCCMatrix<int> CCCDataReader::getContactMatrix(pair<string, string> chrPair) {
  assert(interContactMatrices.count(chrPair) != 0);
  return interContactMatrices[chrPair];
}


vector<CCCMatrix<int> > CCCDataReader::getContactMatrices() {
  vector<string> chromosomes = this->getChromosomes();
  vector<CCCMatrix<int> > res;
  typedef vector<string>::iterator it;
  for(it iter=chromosomes.begin(); iter != chromosomes.end(); iter++) {
    res.push_back(this->getContactMatrix(*iter));
  }
  return res;
}


vector<string> CCCDataReader::getChromosomes(bool onlyIntra/*=true*/) {
  vector<string> res;
  typedef map<string,CCCMatrix<int> >::iterator it;
  for(it iter=intraContactMatrices.begin(); iter!=intraContactMatrices.end(); iter++) {
    res.push_back(iter->first);
  }
  if(onlyIntra) {
    return res;
  }
  typedef map<pair<string,string>,CCCMatrix<int> >::iterator it2;
  for(it2 iter2=interContactMatrices.begin(); iter2!=interContactMatrices.end(); iter2++) {
    if(find(res.begin(), res.end(), iter2->first.first) == res.end()) {
      res.push_back(iter2->first.first);
    }
    if(find(res.begin(), res.end(), iter2->first.second) == res.end()) {
       res.push_back(iter2->first.second);
    }   
  }
  return res;

}

vector<pair<string, string> > CCCDataReader::getInterChromosomePairs() {
  vector<pair<string, string> > res;
  typedef map<pair<string, string>,CCCMatrix<int> >::iterator it;
  for(it iter=interContactMatrices.begin(); iter!=interContactMatrices.end(); iter++) {
    res.push_back(iter->first);
  }
  return res;
}
